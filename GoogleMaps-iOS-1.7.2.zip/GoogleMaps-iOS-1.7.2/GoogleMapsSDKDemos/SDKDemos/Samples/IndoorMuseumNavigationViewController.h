#import <UIKit/UIKit.h>

#import <GoogleMaps/GoogleMaps.h>

@interface IndoorMuseumNavigationViewController : UIViewController<
  GMSMapViewDelegate,
  GMSIndoorDisplayDelegate>

@end
