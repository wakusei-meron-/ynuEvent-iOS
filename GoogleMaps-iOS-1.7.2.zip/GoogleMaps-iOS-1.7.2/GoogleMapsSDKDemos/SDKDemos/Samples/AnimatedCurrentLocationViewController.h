
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>

#import <GoogleMaps/GoogleMaps.h>

@interface AnimatedCurrentLocationViewController : UIViewController<CLLocationManagerDelegate>

@end
