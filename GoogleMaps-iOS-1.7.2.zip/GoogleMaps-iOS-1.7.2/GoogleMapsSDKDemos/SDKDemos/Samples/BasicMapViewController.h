#import <UIKit/UIKit.h>

@interface BasicMapViewController : UIViewController

@end
